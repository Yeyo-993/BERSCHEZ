# BERSCHEZ
Es un ecommerce de venta de ropa online es un proyecto para el sena y una empresa de venta de dotacion ubicada en la ciudad de Bogotá

##Instacion del proyecto
Para ver el proyecto toca agregar la carpeta con los archivos a htdocs de la carpeta xampp
